function preload() {
  song = loadSound('bounce.wav');
  font = loadFont('KuiperBelt.otf');
}
var wind;
var position;

var balls = [];

var circle = {
  x: 100,
  y: 400,
  vx: 6,
  vy: -4,
  r: 50,
  h: 100
};

var circle2 = {
  x: 120,
  y: 360,
  vx: 2,
  vy: -4,
  r: 50,
  h: 120
};

var circle3 = {
  x: 140,
  y: 380,
  vx: 5,
  vy: -4,
  r: 50,
  h: 180
};



function setup() {

  createCanvas(1000, 750);
  textFont(font);
  textSize(30);

  reverb = new p5.Reverb();
  colorMode(HSB,100);
  circle.x = random(width);
  circle2.x = random(width);
  circle3.x = random(width);
  circle.h = random(360);
  circle2.h = random(360);
  circle3.h = random(360);
}

function draw() {
  
  background(0, 30);
  for (i = 0; i < 1500; i = i + 1) {
    fill(100,50);
    ellipse(random(width),random(height), 3)
  }
    fill(100);
  textAlign(CENTER);
  textSize(20);
  text('Press up arrow to make balloons bigger', width/2, 40);
    text('Press down arrow to make balloons smaller', width/2, 60);
  text('Press space to reset', width/2, 80);
   balls.forEach(drawBall);
  balls.forEach(moveBall);
  balls.forEach(bounceBall);
  noStroke();
  paint(circle);
  paint(circle2);
  paint(circle3);
  move(circle);
  move(circle2);
  move(circle3);
  bounce(circle);
  bounce(circle2);
  bounce(circle3);
  keyPressed();


}


function paint(circle) {
  fill(circle.h, 100, 100,80);
  ellipse(circle.x, circle.y, circle.r * 2, circle.r * 2);
}

function move(circle) {
  circle.x += circle.vx;
  // circle.x = circle.x + circle.vx
  circle.y += circle.vy;
}

function bounce(circle) {
  if (circle.x > width || circle.x < 0) {
    circle.vx = -circle.vx;
    song.play();
  }
  if (circle.y > height || circle.y < 0) {
    circle.vy = -circle.vy;
    song.play();
  }
}


function keyPressed() {

  if (keyCode == UP_ARROW && (circle.r < 200)) {
    circle.r = circle.r + 1;
    circle2.r = circle2.r + 1;
    circle3.r = circle3.r + 1;
 
  
  } else if (keyCode === DOWN_ARROW && (circle.r > 10)) {
    circle.r = circle.r - 1;
    circle2.r = circle2.r - 1;
    circle3.r = circle3.r -1;
    

  }
  else if (keyCode === 32 && (circle.r >=50)) {
    circle.r = circle.r - 1;
circle2.r = circle2.r - 1;
    circle3.r = circle3.r -1;

  }
      else if (keyCode == 13) {
     if (balls.length > 0)
          balls.splice(0 , 1);  }
  
}




function drawBall(ball) {

  push();
  colorMode(HSB);
 
  fill(ball.h, 100, 100, 50);
  ellipse(ball.x, ball.y, circle.r);
  pop();

}

function mousePressed(ball) {
  balls.push({
    x: mouseX,
    y: mouseY,
    vx: random(10),
    vy:random(10),
 
    h: random(300), })

      
	
}


function moveBall(ball) {
  
 ball.x += ball.vx;
  ball.y += ball.vy;
}


function bounceBall(ball) {
  if (ball.x > width || ball.x < 0) {
    ball.vx = -circle.vx;
   
  }
  if (ball.y > height || ball.y < 0) {
    ball.vy = -ball.vy;

  }
}



